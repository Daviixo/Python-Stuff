import pymongo

def Test_Mongo():

  client = pymongo.MongoClient(('mongodb://143.244.190.214:27017'))
  dbnames = client.list_database_names()
  if 'creditcards' in dbnames:
    print("It's there!")
    mydb = client["creditcards"]
    mycol = mydb["inventory"]

    mytest = { "Credit Card" : "TEST1234" }

    y = mycol.insert_one(mytest)

    for x in mycol.find():
      print(x)

  else:
    print("Noup, not here...")


if __name__ == "__main__":
  Test_Mongo()    